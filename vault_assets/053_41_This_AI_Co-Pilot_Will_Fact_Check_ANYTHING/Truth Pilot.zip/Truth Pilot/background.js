chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkFacts") {
    fetch("https://hook.eu2.make.com/xah3emln6tnfgxjtaiid583m5vzamfyi", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ text: request.text, url: request.url }),
    })
      .then((response) => response.text())
      .then((result) => {
        chrome.tabs.sendMessage(sender.tab.id, { action: "displayResult", result: result });
      })
      .catch((error) => {
        console.error("Error:", error);
        chrome.tabs.sendMessage(sender.tab.id, { action: "displayResult", result: "An error occurred while fact-checking." });
      });
  }
});