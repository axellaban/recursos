let resultBox = null;
let loadingAnimation = null;

function showResult(result) {
  if (loadingAnimation) {
    loadingAnimation.remove();
    loadingAnimation = null;
  }
  if (resultBox) {
    resultBox.remove();
  }
  const verdict = getVerdict(result);
  const gradientClass = getGradientClass(verdict);
  resultBox = document.createElement('div');
  resultBox.id = 'truth-pilot-result';
  resultBox.innerHTML = `
    <div class="truth-pilot-header ${gradientClass}">
      <h3>Truth Pilot Result</h3>
      <button id="truth-pilot-close" aria-label="Close result">×</button>
    </div>
    <div class="truth-pilot-content">
      ${formatResult(result)}
    </div>
  `;
  document.body.appendChild(resultBox);
  document.getElementById('truth-pilot-close').addEventListener('click', () => {
    resultBox.remove();
    resultBox = null;
  });
  animateResultAppearance();
}

function formatResult(result) {
  result = result.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  result = result.replace(/\[(.*?)\]\((https?:\/\/[^\s]+)\)/g, '<a href="$2" target="_blank">$1</a>');
  result = result.replace(/\n\n/g, '</p><p>').replace(/\n/g, '<br>');
  return `<p>${result}</p>`;
}

function getVerdict(result) {
  const lowerResult = result.toLowerCase();
  if (lowerResult.includes("true")) return "true";
  if (lowerResult.includes("false")) return "false";
  if (lowerResult.includes("misleading")) return "misleading";
  return "unverifiable";
}

function getGradientClass(verdict) {
  switch (verdict) {
    case "true": return "gradient-green";
    case "false": return "gradient-red";
    case "misleading": return "gradient-black";
    default: return "gradient-purple";
  }
}

function showLoadingAnimation() {
  if (loadingAnimation) {
    loadingAnimation.remove();
  }
  loadingAnimation = document.createElement('div');
  loadingAnimation.id = 'truth-pilot-loading';
  loadingAnimation.innerHTML = `
    <div class="truth-pilot-header gradient-loading">
      <h3>Truth Pilot Result</h3>
    </div>
    <div class="truth-pilot-spinner"></div>
    <div id="loading-text" class="truth-pilot-loading-text">Fact checking...</div>
  `;
  document.body.appendChild(loadingAnimation);
  cycleLoadingText();
}

function cycleLoadingText() {
  const loadingTexts = [
    "Fact checking...",
    "Comparing sources...",
    "Searching the internet...",
    "Making magic happen...",
    "Drinking coffee ☕️"
  ];
  let index = 0;
  const loadingTextElement = document.getElementById('loading-text');
  const intervalId = setInterval(() => {
    if (!document.getElementById('loading-text')) {
      clearInterval(intervalId);
      return;
    }
    loadingTextElement.textContent = loadingTexts[index];
    index = (index + 1) % loadingTexts.length;
  }, 2000);
}

function animateResultAppearance() {
  resultBox.style.opacity = '0';
  resultBox.style.transform = 'translateY(-20px)';
  setTimeout(() => {
    resultBox.style.opacity = '1';
    resultBox.style.transform = 'translateY(0)';
  }, 50);
}

function getSelectedTextAndSendRequest() {
  const selectedText = window.getSelection().toString().trim();
  if (selectedText) {
    chrome.runtime.sendMessage({ 
      action: "checkFacts", 
      text: selectedText,
      url: window.location.href
    });
    showLoadingAnimation();
    createConfetti();
  } else {
    alert("Please select some text to fact-check.");
  }
}

function createConfetti() {
  const confettiCount = 100;
  const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];

  for (let i = 0; i < confettiCount; i++) {
    const confetti = document.createElement('div');
    confetti.className = 'confetti';
    confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    confetti.style.left = Math.random() * 100 + 'vw';
    confetti.style.animationDuration = (Math.random() * 3 + 2) + 's';
    confetti.style.opacity = Math.random();
    document.body.appendChild(confetti);

    setTimeout(() => confetti.remove(), 5000);
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "displayResult") {
    showResult(request.result);
  }
});

(function() {
  const style = document.createElement('style');
  style.textContent = `
    @keyframes gradientAnimation {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    #truth-pilot-result, #truth-pilot-loading {
      position: fixed;
      top: 20px;
      right: 20px;
      width: 350px;
      max-height: 80vh;
      overflow-y: auto;
      background-color: #ffffff;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      z-index: 9999;
      font-family: Avenir, Roboto, Arial, sans-serif;
      transition: opacity 0.3s ease, transform 0.3s ease;
    }
    .truth-pilot-header {
      position: sticky;
      top: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 15px;
      border-top-left-radius: 8px;
      border-top-right-radius: 8px;
      color: #ffffff;
    }
    .truth-pilot-header h3 {
      margin: 0;
      font-size: 20px;
      font-weight: 700;
    }
    .truth-pilot-content {
      padding: 15px;
    }
    .truth-pilot-content a {
      color: #1a0dab;
      text-decoration: none;
    }
    .truth-pilot-content a:hover {
      text-decoration: underline;
    }
    #truth-pilot-close {
      position: absolute;
      top: 10px;
      right: 10px;
      background: none;
      border: none;
      font-size: 24px;
      color: #ffffff;
      cursor: pointer;
    }
    .truth-pilot-spinner {
      width: 40px;
      height: 40px;
      margin: 20px auto;
      border-radius: 50%;
      border: 4px solid transparent;
      border-top-color: #ffffff;
      animation: spin 1s linear infinite;
    }
    .truth-pilot-loading-text {
      text-align: center;
      margin-bottom: 20px;
      font-style: italic;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    .gradient-green {
      background: linear-gradient(-45deg, #4CAF50, #8BC34A, #4CAF50, #8BC34A);
      background-size: 400% 400%;
      animation: gradientAnimation 5s ease infinite;
    }
    .gradient-red {
      background: linear-gradient(-45deg, #F44336, #FF9800, #F44336, #FF9800);
      background-size: 400% 400%;
      animation: gradientAnimation 5s ease infinite;
    }
    .gradient-black {
      background: linear-gradient(-45deg, #212121, #757575, #212121, #757575);
      background-size: 400% 400%;
      animation: gradientAnimation 5s ease infinite;
    }
    .gradient-purple {
      background: linear-gradient(-45deg, #9C27B0, #E91E63, #9C27B0, #E91E63);
      background-size: 400% 400%;
      animation: gradientAnimation 5s ease infinite;
    }
    .gradient-loading {
      background: linear-gradient(-45deg, #4CAF50, #F44336, #212121, #9C27B0);
      background-size: 400% 400%;
      animation: gradientAnimation 5s ease infinite;
    }
    .confetti {
      position: fixed;
      width: 10px;
      height: 10px;
      background-color: #f00;
      animation: confetti-fall 5s linear infinite;
      z-index: 10000;
    }
    @keyframes confetti-fall {
      0% { transform: translateY(-100vh) rotate(0deg); }
      100% { transform: translateY(100vh) rotate(720deg); }
    }
  `;
  document.head.appendChild(style);
})();

getSelectedTextAndSendRequest();