console.log('Popup script loaded');

// You can add more debugging functionality here if needed