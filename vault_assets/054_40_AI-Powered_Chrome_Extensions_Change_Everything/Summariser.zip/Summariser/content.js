// content.js
console.log('Content script loaded');

function createSummarizeButton() {
    const summarizeButton = document.createElement('button');
    summarizeButton.id = 'summarize-button';
    summarizeButton.innerHTML = 'SUMMARISE <span id="loading-icon" style="display:none;">⏳</span>';
    summarizeButton.style.backgroundColor = '#1f51ff';
    summarizeButton.style.color = '#fff';
    summarizeButton.style.border = 'none';
    summarizeButton.style.borderRadius = '18px';
    summarizeButton.style.padding = '10px 16px';
    summarizeButton.style.marginLeft = '8px';
    summarizeButton.style.cursor = 'pointer';
    summarizeButton.style.fontSize = '14px';
    summarizeButton.style.fontWeight = 'bold';
    summarizeButton.style.textTransform = 'uppercase';
    summarizeButton.style.fontFamily = 'Avenir, Roboto, Arial, sans-serif';
    summarizeButton.style.boxShadow = '0 0 10px #1f51ff';
    summarizeButton.style.transition = 'all 0.3s ease';

    summarizeButton.onmouseover = function() {
        this.style.boxShadow = '0 0 15px #1f51ff';
        this.style.transform = 'scale(1.05)';
    };
    summarizeButton.onmouseout = function() {
        this.style.boxShadow = '0 0 10px #1f51ff';
        this.style.transform = 'scale(1)';
    };

    summarizeButton.addEventListener('click', () => {
        console.log('Summarize button clicked');
        triggerConfetti();
        getTranscript();
        document.getElementById('loading-icon').style.display = 'inline';
    });

    return summarizeButton;
}

function addSummarizeButton() {
    console.log('Attempting to add Summarize button');
    if (document.querySelector('#summarize-button')) {
        console.log('Summarize button already exists');
        return;
    }

    const subscribeButton = document.querySelector('ytd-subscribe-button-renderer');
    if (subscribeButton) {
        console.log('Subscribe button found, adding Summarize button');
        const summarizeButton = createSummarizeButton();
        subscribeButton.parentNode.insertBefore(summarizeButton, subscribeButton);
        console.log('Summarize button added successfully');
    } else {
        console.log('Subscribe button not found, retrying...');
        setTimeout(addSummarizeButton, 1000);
    }
}

function triggerConfetti() {
    const confettiCount = 200;
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];

    for (let i = 0; i < confettiCount; i++) {
        const confetti = document.createElement('div');
        confetti.style.position = 'fixed';
        confetti.style.width = '10px';
        confetti.style.height = '10px';
        confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.left = Math.random() * 100 + 'vw';
        confetti.style.top = '-10px';
        confetti.style.zIndex = '10000';
        confetti.style.borderRadius = '50%';
        confetti.style.opacity = Math.random() * 0.5 + 0.5;
        confetti.style.animation = `fall ${Math.random() * 3 + 2}s linear`;
        document.body.appendChild(confetti);

        setTimeout(() => {
            document.body.removeChild(confetti);
        }, 5000);
    }

    const style = document.createElement('style');
    style.textContent = `
        @keyframes fall {
            to {
                transform: translateY(100vh) rotate(720deg);
            }
        }
    `;
    document.head.appendChild(style);
}

function getVideoId() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('v');
}

async function getTranscript() {
    const videoId = getVideoId();
    if (!videoId) {
        console.error('Could not find video ID');
        alert('Could not find video ID. Please make sure you are on a YouTube video page.');
        return;
    }

    try {
        console.log('Fetching video data...');
        const apiUrl = `https://www.youtube.com/youtubei/v1/player?key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8`;
        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                videoId: videoId,
                context: {
                    client: {
                        clientName: 'WEB',
                        clientVersion: '2.20210721.00.00',
                    }
                }
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log('Video data fetched and parsed successfully');

        if (!data.captions || !data.captions.playerCaptionsTracklistRenderer) {
            console.error('No captions data found in the response');
            throw new Error('No captions data found in the YouTube API response');
        }

        const captionTracks = data.captions.playerCaptionsTracklistRenderer.captionTracks;
        if (!captionTracks || captionTracks.length === 0) {
            console.error('No caption tracks found');
            alert('No captions found for this video. The video might not have any captions available.');
            return;
        }

        console.log('Caption tracks found:', captionTracks);

        const englishTrack = captionTracks.find(track => track.languageCode === 'en') || captionTracks[0];
        console.log('Selected track:', englishTrack);

        console.log('Fetching transcript...');
        const transcriptResponse = await fetch(englishTrack.baseUrl);
        if (!transcriptResponse.ok) {
            throw new Error(`HTTP error! status: ${transcriptResponse.status}`);
        }
        const transcriptText = await transcriptResponse.text();
        console.log('Transcript fetched successfully');

        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(transcriptText, 'text/xml');
        const textElements = xmlDoc.getElementsByTagName('text');

        let transcript = '';
        for (let i = 0; i < textElements.length; i++) {
            transcript += textElements[i].textContent + ' ';
        }

        console.log('Transcript extracted successfully');
        sendTranscriptToWebhook(transcript.trim());
    } catch (error) {
        console.error('Error fetching transcript:', error);
        alert(`Error fetching transcript: ${error.message}. Please check the console for more details.`);
        document.getElementById('loading-icon').style.display = 'none';
    }
}

function displaySummary(summary) {
    const existingSummaryBox = document.getElementById('summarize-summary-box');
    if (existingSummaryBox) {
        existingSummaryBox.remove();
    }

    const summaryBox = document.createElement('div');
    summaryBox.id = 'summarize-summary-box';
    summaryBox.innerHTML = `
        <div class="gradient-header"></div>
        <h3>Video Summary</h3>
        <button id="close-summary" aria-label="Close summary">×</button>
        <p style="white-space: pre-wrap;">${summary}</p>
    `;
    document.body.appendChild(summaryBox);

    const closeButton = document.getElementById('close-summary');
    closeButton.addEventListener('click', () => {
        summaryBox.remove();
    });

    const style = document.createElement('style');
    style.textContent = `
        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        #summarize-summary-box {
            position: fixed;
            right: 20px;
            top: 80px;
            width: 300px;
            max-height: 80vh;
            overflow-y: auto;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            z-index: 9000;
            font-family: 'Avenir', 'Roboto', Arial, sans-serif;
            transition: all 0.3s ease;
        }

        #summarize-summary-box .gradient-header {
            height: 6px;
            background: linear-gradient(90deg, #1f51ff, #4af2a1, #1f51ff);
            background-size: 200% 200%;
            animation: gradientAnimation 5s ease infinite;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
        }

        #summarize-summary-box h3 {
            margin: 0;
            padding: 16px 20px;
            color: #1f51ff;
            font-size: 18px;
            font-weight: 600;
        }

        #summarize-summary-box p {
            padding: 0 20px 20px;
            margin: 0;
            line-height: 1.6;
            color: #333;
            font-size: 14px;
        }

        #close-summary {
            position: absolute;
            top: 12px;
            right: 12px;
            background: none;
            border: none;
            color: #1f51ff;
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            line-height: 1;
        }

        #close-summary:hover {
            color: #ff4d4d;
        }
    `;
    document.head.appendChild(style);
}

function sendTranscriptToWebhook(transcript) {
    console.log('Sending transcript to webhook');
    fetch("https://hook.eu2.make.com/lvfclphru7edpc29lujtn78aer13w9ue", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ transcript: transcript })
    }).then(async response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const responseText = await response.text();
        console.log("Raw response:", responseText);
        try {
            return JSON.parse(responseText);
        } catch (e) {
            console.log("Response is not JSON, using as-is");
            return { summary: responseText };
        }
    }).then(data => {
        console.log("Transcript sent successfully. Response:", data);
        if (data.summary) {
            displaySummary(data.summary);
        } else {
            console.error("No summary found in the response");
        }
        alert("Transcript processed successfully!");
    }).catch(error => {
        console.error("Error sending transcript:", error);
        alert(`Error sending transcript: ${error.message}. Check console for details.`);
    }).finally(() => {
        document.getElementById('loading-icon').style.display = 'none';
    });
}

function initializeContentScript() {
    console.log('Initializing content script');
    addSummarizeButton();
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Message received in content script:', request);
    if (request.action === "pageLoaded") {
        initializeContentScript();
    }
    sendResponse({status: "Message received"});
});

// Initialize on load as a fallback
window.addEventListener('load', initializeContentScript);

// Add a mutation observer to handle dynamic page changes
const observer = new MutationObserver((mutations) => {
    for (let mutation of mutations) {
        if (mutation.type === 'childList') {
            addSummarizeButton();
            break;
        }
    }
});

observer.observe(document.body, { childList: true, subtree: true });

console.log('Content script finished loading');
